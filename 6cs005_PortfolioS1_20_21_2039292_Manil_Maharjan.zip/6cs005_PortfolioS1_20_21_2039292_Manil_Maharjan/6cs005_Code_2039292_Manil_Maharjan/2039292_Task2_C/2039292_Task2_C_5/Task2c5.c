#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>
#include <time.h>
#include <pthread.h>
/******************************************************************************
  Compile with:
    gcc Task2c5.c -o task5 -lcrypt -pthread

  Run with:
    ./task5
******************************************************************************/

int count=0;
int t, w, s;     // Loop counters
char salt[7];    // String used in hashing the password. Need space for \0
char plain[7];   // The combination of letters currently being checked
char *enc;       // Pointer to the encrypted password  
pthread_t t1,t2;

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}

void thread_possix(char *passs)
{
	void *kernel_function_1();
	void *kernel_function_2();
	
	pthread_create(&t1, NULL, kernel_function_1, passs);
	pthread_create(&t2, NULL, kernel_function_2, passs);
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);		
}


void *kernel_function_1(char *salt_and_encrypted){
  time_t start = time(NULL);
  
  substr(salt, salt_and_encrypted, 0, 6);

  for(t='A'; t<='M'; t++){
    for(w='A'; w<='Z'; w++){
      for(s=0; s<=99; s++){
        sprintf(plain, "%c%c%02d", t, w, s); 
        enc = (char *) crypt(plain, salt);
        count++;
        if(strcmp(salt_and_encrypted, enc) == 0){
          printf("#%-8d%s %s\n", count, plain, enc);
          printf("Time of solution found: %.2f Sec\n", (double)(time(NULL) - start));
          printf("Time of solution found: %.2f NanoSec\n", (double)(time(NULL) - start)*1.0e9);
          pthread_cancel(t2);
          return 0;
        }  
      }
    }
  }
}


void *kernel_function_2(char *salt_and_encrypted){
  time_t start = time(NULL);
  
  substr(salt, salt_and_encrypted, 0, 6);

  for(t='N'; t<='Z'; t++){
    for(w='A'; w<='Z'; w++){
      for(s=0; s<=99; s++){
        sprintf(plain, "%c%c%02d", t, w, s); 
        enc = (char *) crypt(plain, salt);

        count++;
        if(strcmp(salt_and_encrypted, enc) == 0){
          printf("#%-8d%s %s\n", count, plain, enc);
          printf("Time of solution found : %.2f Sec\n\n", (double)(time(NULL) - start));
          printf("Time of solution found : %.2f NanoSec\n\n", (double)(time(NULL) - start)*1.0e9);
          pthread_cancel(t1);
          return 0;
        } 
      }
    }
  }
}
int time_difference(struct timespec *start, struct timespec *finish, 
                    long long int *difference) {
  long long int ds =  finish->tv_sec - start->tv_sec; 
  long long int dn =  finish->tv_nsec - start->tv_nsec; 

  if(dn < 0 ) {
    ds--;
    dn += 1000000000; 
  } 
  *difference = ds * 1000000000 + dn;
  return !(*difference > 0);
}


int main(int argc, char *argv[]) {

  struct timespec start, finish;   
  long long int time_elapsed;
  clock_gettime(CLOCK_MONOTONIC, &start);
  thread_possix("$6$AS$kWrOptaZOfZkx54tfTrSEx9t.RCVulFlbGcGfB4mdisiKZ9v2JUontXss7mxSL1gc3s8FWx8F57bnNHA9SRxs1");
  printf("%d solutions explored\n", count);
  clock_gettime(CLOCK_MONOTONIC, &finish); 
  time_difference(&start, &finish, &time_elapsed);
  printf("Time elapsed was %lldns or %0.9lfs\n", time_elapsed, 
         (time_elapsed/1.0e9));
  return 0;
}

