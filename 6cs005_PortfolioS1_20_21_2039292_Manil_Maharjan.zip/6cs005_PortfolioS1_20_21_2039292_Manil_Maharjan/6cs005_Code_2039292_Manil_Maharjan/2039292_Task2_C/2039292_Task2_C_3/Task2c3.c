#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <crypt.h>


/******************************************************************************
  	Compile with:

    gcc  Task2c3.c -o task3 -lcrypt

	Run with:
    ./task3 

******************************************************************************/



int count=0;  // Counter for combination of code explored

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';

}

void crack(char *salt_and_encrypted){

   time_t start = time(NULL);
   
  int x, y, z, p;  // Loop counters
  char salt[8];    // Used for encrypting the password
  char plain[8];   // The combination of letters currently being checked 
  char *enc;       // Encrypted password pointer

  substr(salt, salt_and_encrypted, 0, 7);

  for(x='A'; x<='Z'; x++){
    for(y='A'; y<='Z'; y++){
    	for(p = 'A'; p<='Z'; p++){
      for(z=0; z<=99; z++){
        sprintf(plain, "%c%c%c%02d", x, y,p, z); 
        enc = (char *) crypt(plain, salt);
        count++;
        if(strcmp(salt_and_encrypted, enc) == 0){
	    printf("#%-8d%s %s\n", count, plain, enc);
	       printf(" ---> Time Elapsed : %.2f Sec\n\n", (double)(time(NULL) - start)*1.0e9);
		return;	//uncomment this line if you want to speed-up the running time, program will find you the cracked password only without exploring all possibilites

        } 

      }

      }

    }

  }

}

int time_difference(struct timespec *start, struct timespec *finish, 
                    long long int *difference) {
  long long int ds =  finish->tv_sec - start->tv_sec; 
  long long int dn =  finish->tv_nsec - start->tv_nsec; 

  if(dn < 0 ) {
    ds--;
    dn += 1000000000; 
  } 
  *difference = ds * 1000000000 + dn;
  return !(*difference > 0);
}

int main(int argc, char *argv[]){

  struct timespec start, finish;   
  long long int time_elapsed;
  clock_gettime(CLOCK_MONOTONIC, &start);
  
  crack("$6$AS$AFJmizrBfto1/GGYD1vwRU9c/AXkiR0BhNrCXMzqEFKaKCgqoCq4BC7EHOZVq0CjD137OpXk1LgYErGz0HLrW0");
  		//Copy and Paste your encrypted password here using EncryptShA512 program

  printf("%d solutions explored\n", count);
  
  clock_gettime(CLOCK_MONOTONIC, &finish); 
  time_difference(&start, &finish, &time_elapsed);
  printf("Time taken %lldns or %0.9lfs\n", time_elapsed, 
         (time_elapsed/1.0e9));

  return 0;

}
