#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <crypt.h>
#include <unistd.h>
/******************************************************************************
  Compile with:
    gcc EncryptSHA512.c -o enc -lcrypt
    
  If the  password to be encrypted is "CD12" then do this:
    ./EncryptSHA512 CD12
    
    Encrypted Password (CD12): $6$AS$kWrOptaZOfZkx54tfTrSEx9t.RCVulFlbGcGfB4mdisiKZ9v2JUontXss7mxSL1gc3s8FWx8F57bnNHA9SRxs1
    Encrypted Password (BCD12): $6$AS$AFJmizrBfto1/GGYD1vwRU9c/AXkiR0BhNrCXMzqEFKaKCgqoCq4BC7EHOZVq0CjD137OpXk1LgYErGz0HLrW0


******************************************************************************/

#define SALT "$6$AS$"

int main(int argc, char *argv[]){
  
  printf("Encrypted:%s\n", crypt(argv[1], SALT));

  return 0;
}
