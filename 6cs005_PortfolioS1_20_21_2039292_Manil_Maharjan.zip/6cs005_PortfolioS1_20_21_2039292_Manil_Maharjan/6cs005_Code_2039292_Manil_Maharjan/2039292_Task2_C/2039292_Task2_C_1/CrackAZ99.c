#include <stdio.h>
#include <time.h>
#include <crypt.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>


/*****************************************************************************

  Compile with:
    gcc CrackAZ99.c -o crack -lcrypt

  Run with:
    ./crack 

******************************************************************************/

int count=0;     // Counter for combination of code explored


void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}


void crack(char *salt_and_encrypted){
  int x, y, z;     
  char salt[7];    // Used for encrypting the password
  char plain[7];   
  char *enc;       // Encrypted password pointer

  substr(salt, salt_and_encrypted, 0, 6);

  for(x='A'; x<='Z'; x++){
    for(y='A'; y<='Z'; y++){
      for(z=0; z<=99; z++){
        sprintf(plain, "%c%c%02d", x, y, z); 
        enc = (char *) crypt(plain, salt);
        count++;
        if(strcmp(salt_and_encrypted, enc) == 0){
	    printf("#%-8d%s %s\n", count, plain, enc);
	return;	
        } 
      }
    }
  }
}

int time_difference(struct timespec *start, struct timespec *finish, 
                    long long int *difference) {
  long long int ds =  finish->tv_sec - start->tv_sec; 
  long long int dn =  finish->tv_nsec - start->tv_nsec; 

  if(dn < 0 ) {
    ds--;
    dn += 1000000000; 
  } 
  *difference = ds * 1000000000 + dn;
  return !(*difference > 0);
}


int main(int argc, char *argv[]){
  struct timespec start, finish;   
  long long int time_elapsed;
  clock_gettime(CLOCK_MONOTONIC, &start);
  
  crack("$6$AS$kWrOptaZOfZkx54tfTrSEx9t.RCVulFlbGcGfB4mdisiKZ9v2JUontXss7mxSL1gc3s8FWx8F57bnNHA9SRxs1");
  //Put encrypted password here using EncryptShA512 program
  printf("%d solutions explored\n", count);
  
  clock_gettime(CLOCK_MONOTONIC, &finish); 
  time_difference(&start, &finish, &time_elapsed);
  printf("Time elapsed was %lldns or %0.9lfs\n", time_elapsed, (time_elapsed/1.0e9));

  return 0;
}

