#include<stdio.h>

int main(){
	int A=4;
	int temp_B= 4;
	int D=4l
	
	int C= temp_B+D;

	int new_B =A+Cl
	int B= C+D;

	printf("B and C :");
	printf("\nB=%d\n",new_B);
	printf("\nB=%d\n",B);
	printf("C=%d\n",C);

return 0;
}